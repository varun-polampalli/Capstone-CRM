import Navbar2 from "./Navbar2";

function Productsadmin(){
    return(
        <div>
            <Navbar2/>
            <center>
                    
                    <table >
                        <tr><td><img src="./images/mobile2.png" width="60%" /></td><td><img src="./images/mobile2.png" width="60%" /></td><td><img src="./images/mobile3.png" width="60%" /></td><td><img src="./images/mobile4.png" width="60%" /></td></tr>
                        <tr><td ><h5>Iphone5R</h5>   $150</td><td><h5>Iphone5R</h5>   $150</td><td><h5>Samsung Galaxy</h5>   $220</td><td><h5>   Moto G8</h5>   $200</td></tr>&nbsp;
                        <tr><td><img src="./images/airpodes3.png" width="60%" /></td><td><img src="./images/airpodes1.png" width="60%" /></td><td><img src="./images/airpodes2.png" width="60%" /></td><td><img src="./images/airpodes4.png" width="60%" /></td></tr>
                        <tr><td ><h5>Boat Airdopes 131</h5>   $129</td><td><h5>Realme Buds Air 5</h5>   $150</td><td><h5>JBL Tune</h5>   $120</td><td><h5>   Iphone Air 5</h5>   $180</td></tr>&nbsp;
                        <tr><td><img src="./images/airpodes6.png" width="60%" /></td><td><img src="./images/airpodes7.png" width="60%" /></td><td><img src="./images/airpodes8.png" width="60%" /></td><td><img src="./images/airpodes9.png" width="60%" /></td></tr>
                        <tr><td ><h5>BoAt bassheads</h5>   $150</td><td><h5>Sony Classic </h5>   $180</td><td><h5>Sony Galaxy</h5>   $220</td><td><h5>   Sony HBR XB400 Black</h5>   $200</td></tr>&nbsp;
                    </table>
                </center>
        </div>
    );
}
export default Productsadmin;