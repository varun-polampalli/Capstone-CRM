import react from 'react';
import Navbar1 from './Navbar1';
/* import "./faq.css"; */
function Faq() {
  return(
    <div>
    <Navbar1/>
    </div>
  );
}

export default Faq