import React from 'react';
import Navbar1 from "./Navbar1";
import { BrowserRouter,Router, Routes, Route } from "react-router-dom";



function UserMenu() {
    return (
        <div>
         
            <Navbar1 />
            
        
        
        
            
    
      {/*<nav>
      import { Link } from 'react-router-dom';
        <Link to="/">Home</Link>
        <Link to="/products">Products</Link>
        <Link to="/contact">Contact</Link>
    </nav>*/}
      </div>
    );
  }

   

export default UserMenu;

