import Navbar1 from "./Navbar1";
function IssueRaised(){
    return(
        <div>
            <Navbar1/>
            <center>
            <img src="images/incident.png"/>
            Incident raised..!
            </center>
        </div>
    );
}
export default IssueRaised;