import React from "react";
/* import ChatBot from 'react-simple-chatbot'; */
 
function Chatbot() {

    return (
<div >
<Chatbot const steps={[
    {
      id:'Greet',
      message:'Hello,Welcome to our Website',
      trigger:'Ask Name'
    },
    {
      id:'Ask Name',
      message:'Please enter your Name',
      trigger:'waiting1'
    },
    {
      id:'waiting1',
      user:true,
      trigger:'Name'
    },
    {
      id:'Name',
      message:'HI {previousValue},Please select your issue',
      trigger:'issues'
    },
    {
      id:'issues',
      options:[{ value:"React",label:'React',trigger:"React"},
    { value:"Angular",label:'Angular',trigger:"Angular"}],      
    },
    {
      id:'React',
      message:'Thanks for isssue',
      end:true
    },
    {
      id:'Angular',
      message:'Thanks for issue1',
      end:true
 
    }]}
  floating={true}
/>
 
    </div>
  );
}
 
export default Chatbot;