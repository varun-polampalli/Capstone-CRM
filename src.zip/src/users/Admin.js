import React from 'react';
import Navbar2 from "./Navbar2";

function Admin() {
    return (
        <div>
         
            <Navbar2 />
    
      </div>
    );
  } 

export default Admin;