import Navbar1 from "./Navbar1";

function Paymentdone(){
    return(
        <div>
            <Navbar1/>
            <center>
                <div className=".App-logo">
                <img src="images/paymentsuccess.png" />
                </div>
                <h2>Your Order Placed Successfully..!</h2>
            </center>
        </div>
    );
}
export default Paymentdone;